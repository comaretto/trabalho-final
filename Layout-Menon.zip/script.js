function toggleMenu() {
  var menu = document.querySelector('nav.menu');
  menu.classList.toggle('active');
}

const produtos = [
  { nome: 'Boneca Barbie', imagem: 'img/Barbie.jpg', preco: 129.90 },
  { nome: 'Carro de Controle Remoto', imagem: 'img/carro-controle.jpg', preco: 229.90 },
  { nome: 'Quebra-Cabeça', imagem: 'img/quebra-cabeça.jpg', preco: 69.90 },
  { nome: 'Bola de Futebol', imagem: 'img/Bola.jpg', preco: 99.90 },
];

const productsContainer = document.getElementById('products');

function exibirProdutos() {
  productsContainer.innerHTML = '';
  produtos.forEach(produto => {
    const productCard = document.createElement('div');
    productCard.classList.add('product');
    productCard.innerHTML = `
            <img src="${produto.imagem}" alt="${produto.nome}">
            <h3>${produto.nome}</h3>
            <p>R$ ${produto.preco.toFixed(2)}</p> <!-- Adicionando o preço do produto -->
        `;
    productsContainer.appendChild(productCard);
  });
}

window.onload = exibirProdutos;
